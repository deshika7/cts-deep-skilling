package com.library;

public class LibraryManagementApplication {
    public static void main(String[] args) {
        System.out.println("Spring Maven Project Setup Successful!");
    }
}
