package com.library.service;

public class BookService {
    public void displayService() {
        System.out.println("BookService: Processing book-related operations...");
    }
}
