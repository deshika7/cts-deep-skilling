package com.library.repository;

public class BookRepository {
    public void displayRepository() {
        System.out.println("BookRepository: Fetching books from the database...");
    }
}
